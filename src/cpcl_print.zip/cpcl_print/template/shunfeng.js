const { CPCL } = require('../bluetooth-v2/index');
const { batchAddCommand } = require("../utils/index");

/**
 * @description 顺丰快递单模版
 * @param {Object} config - 模版信息
 * @param {string} config.barcode - 条码信息
 * @param {string} config.expressNo - 顺丰单号
 * @param {string} config.time - 下单时间
 * @param {string} config.senderAddress - 发件人地址
 * @param {string} config.recipientAddress - 收件人地址
 * @param {string} config.thing - 发货物品
 * @param {string} config.qrCode - 二维码信息
 * @param {string} config.qty - 数量
 * @param {string} config.payment - 支付方式
 * @param {string} config.expressType - 快递类型
 * @param {string} config.orderNo - 订单号
 * */
function SF({
  barcode = 'SF6399695948',
  expressNo = 'SF6399695948',
  time = '2023-05-06 14:26:00',
  senderAddress = '这是一段很长的文本，需要自动换行，所以我们使用了TEXT指令的WIDTH参数来指定每行的最大宽度。',
  recipientAddress = '北京市海淀区长春桥路',
  thing = '运动营养香橙黑加仑味耐力固体饮料',
  qrCode = 'https://www.baidu.com',
  qty = 1,
   payment = '微信支付',
  expressType = '标准快递',
  orderNo = '000004999'
} = {}) {
  const command = new CPCL()
  command.init()
    .addCommand(`! 5 200 200 990 1`)
    .addCommand(`PAGE - WIDTH 630`)
    .addCommand(`BOX 10 10 560 990 2`)
    .addCommand(`CENTER`)

    // 条纹码打印 非数字无法打印
    .addCommand(`BARCODE-TEXT OFF`) // 打印条码，不打印条码文本
    .addCommand(`BARCODE 128 2 0 60 0 30 ${barcode}`)
    .addCommand(`LEFT`)
    .addCommand(`T 6 0 20 100 ${expressNo}`)
    .addCommand(`RIGHT`)
    .addCommand(`T 6 0 20 100 ${time}`)
    .addCommand(`LEFT`)
    .addCommand(`LINE 10 130 560 130 2`)

    // 寄件方信息
    .addCommand(`T 6 0 20 145 寄件方信息： `)
    .batchAddCommand(senderAddress, 175)
    .addCommand(`LINE 10 310 560 310 2`)

    // 收件方信息
    .addCommand(`T 6 0 20 325 收件方信息： `)
    .batchAddCommand(recipientAddress, 355)
    .addCommand(`LINE 10 490 560 440 2`)

    // 产品名称
    .batchAddCommand(thing, 505, 305)
    .addCommand(`LINE 10 600 310 550 2`)

    // 二维码
    .addCommand(`LEFT`)
    .addCommand(`B QR 335 520 M 2 U 8`)
    .addCommand(`MA,${qrCode}`)
    .addCommand(`ENDQR`)

    .addCommand(`LINE 310 490 310 900 2`)

    .addCommand(`T 6 0 20 615 `)
    .addCommand(`LINE 10 660 310 660 2`)

    .addCommand(`LINE 150 660 150 840 2`)

    // 件数
    .addCommand(`T 6 0 20 675 件数`)
    .addCommand(`T 6 0 165 675 ${qty}`)
    .addCommand(`LINE 10 720 310 720 2`)

    // 付款方式
    .addCommand(`T 6 0 20 735 付款方式`)
    .addCommand(`T 6 0 165 735 ${payment}`)
    .addCommand(`LINE 10 780 310 780 2`)

    // 快递类型
    .addCommand(`T 6 0 20 795 类型`)
    .addCommand(`T 6 0 165 795 ${expressType}`)
    .addCommand(`LINE 10 840 310 840 2`)

    // 订单号
    .addCommand(`T 6 0 20 855 订单号：`)
    .addCommand(`T 6 0 130 855 ${orderNo}`)
    .addCommand(`LINE 10 900 560 900 2`)

    .addCommand(`FORM`)
    .setPagePrint()

  return command
}

module.exports = {
  SF
}
